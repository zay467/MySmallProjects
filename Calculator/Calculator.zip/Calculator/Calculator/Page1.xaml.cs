﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Calculator
{
    /// <summary>
    /// Interaction logic for Page1.xaml
    /// </summary>
    public partial class Page1 : Page
    {
        public Page1()
        {
            InitializeComponent();
        }
        int pc = 1;
        bool opop = false;
        string op = "";
        double value = 0;

        private void zero(object sender, RoutedEventArgs e)
        {
            if (opop)
            {
                tb.Clear();
            }
            opop = false;
            tb.Text += "0";
            cc();
        }

        private void one(object sender, RoutedEventArgs e)
        {
            if (opop)
            {
                tb.Clear();
            }
            opop = false;
            tb.Text += "1";
            cc();
        }

        private void two(object sender, RoutedEventArgs e)
        {
            if (opop)
            {
                tb.Clear();
            }
            opop = false;
            tb.Text += "2";
            cc();
        }

        private void three(object sender, RoutedEventArgs e)
        {
            if (opop)
            {
                tb.Clear();
            }
            opop = false;
            tb.Text += "3";
            cc();
        }

        private void four(object sender, RoutedEventArgs e)
        {
            if (opop)
            {
                tb.Clear();
            }
            opop = false;
            tb.Text += "4";
            cc();
        }

        private void five(object sender, RoutedEventArgs e)
        {
            if (opop)
            {
                tb.Clear();
            }
            opop = false;
            tb.Text += "5";
            cc();
        }

        private void six(object sender, RoutedEventArgs e)
        {
            if (opop)
            {
                tb.Clear();
            }
            opop = false;
            tb.Text += "6";
            cc();
        }

        private void seven(object sender, RoutedEventArgs e)
        {
            if (opop)
            {
                tb.Clear();
            }
            opop = false;
            tb.Text += "7";
            cc();
        }

        private void eight(object sender, RoutedEventArgs e)
        {
            if (opop)
            {
                tb.Clear();
            }
            opop = false;
            tb.Text += "8";
            cc();
        }

        private void nine(object sender, RoutedEventArgs e)
        {
            if (opop)
            {
                tb.Clear();
            }
            opop = false;
            tb.Text += "9";
            cc();
        }

        private void clear(object sender, RoutedEventArgs e)
        {
            lb.Content = "";
            tb.Clear();
            cc();
        }
        private void dot(object sender, RoutedEventArgs e)
        {
            if (opop)
            {
                tb.Clear();
            }
            opop = false;
            tb.Text += ".";
            cc();
        }
        private void plus(object sender, RoutedEventArgs e)
        {
            if (pc % 2 != 0)
            {
                op = "+";
                value = Double.Parse(tb.Text);
                opop = true;
                lb.Content = value + " " + op;
                tb.Text = "";
                pc += 1;
            }
            else
            {
                MessageBox.Show("Error", "Information", MessageBoxButton.OK,MessageBoxImage.Error);
            }
        }
        private void minus(object sender, RoutedEventArgs e)
        {
            if (pc % 2 != 0)
            {
                op = "-";
                value = Double.Parse(tb.Text);
                opop = true;
                lb.Content = value + " " + op;
                tb.Text = "";
                pc += 1;
            }
            else
            {
                MessageBox.Show("Error", "Information", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void multiply(object sender, RoutedEventArgs e)
        {
            if (pc % 2 != 0)
            {
                op = "*";
                value = Double.Parse(tb.Text);
                opop = true;
                lb.Content = value + " " + op;
                tb.Text = "";
                pc += 1;
            }
            else
            {
                MessageBox.Show("Error", "Information", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void divide(object sender, RoutedEventArgs e)
        {
            if (pc % 2 != 0)
            {
                op = "/";
                value = Double.Parse(tb.Text);
                opop = true;
                lb.Content = value + " " + op;
                tb.Text = "";
                pc += 1;
            }
            else
            {
                MessageBox.Show("Error", "Information", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void modulus(object sender, RoutedEventArgs e)
        {
            if (pc % 2 != 0)
            {
                op = "%";
                value = Double.Parse(tb.Text);
                opop = true;
                lb.Content = value + " " + op;
                tb.Text = "";
                pc += 1;
            }
            else
            {
                MessageBox.Show("Error", "Information", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void sqrt(object sender, RoutedEventArgs e)
        {
            if (pc % 2 != 0)
            {
                op = "Sqrt";
                value = Double.Parse(tb.Text);
                opop = true;
                lb.Content = op + " " + value;
                tb.Text = Math.Sqrt(value).ToString();
                pc += 0 ;
            }
            else
            {
                MessageBox.Show("Error", "Information", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void equal(object sender, RoutedEventArgs e)
        {
            lb.Content = "";
            if (op != "")
            {
                switch (op)
                {
                    case "+":
                        tb.Text = (value + Double.Parse(tb.Text)).ToString();
                        break;
                    case "-":
                        tb.Text = (value - Double.Parse(tb.Text)).ToString();
                        break;
                    case "*":
                        tb.Text = (value * Double.Parse(tb.Text)).ToString();
                        break;
                    case "/":
                        tb.Text = (value / Double.Parse(tb.Text)).ToString();
                        break;
                    case "%":
                        tb.Text = (value + Double.Parse(tb.Text)).ToString();
                        break;
                    default:
                        break;
                }
            }
        }
        private void history(object sender, RoutedEventArgs e)
        {
            Page2 pg = new Page2();
            this.NavigationService.Navigate(pg);
        }
        private void cc()
        {
            pc = 1;
        }
        
    }
}

